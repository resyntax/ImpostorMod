A mod that adds the rather conspicuous impostor into Risk of Rain 2 (BETA, some visual bugs).

Thanks to TheTimesweeper and ArcPh1r3

Fork of: https://github.com/ArcPh1r3/HenryTutorial

Knife model: https://www.thingiverse.com/thing:4612495



DISCLAMER: This is completely non-commercial and I adhere to the CC license. If you have a problem my use of your intellectual property contact me via discord at resyntax#0630